import setuptools
from setuptools import setup

setup(
   name='PersianEncode',
   version='1.0',
   description='encoding persian letters',
   author='BroCode',
   author_email='',
   
   scripts=[
            'PersianEncode.py'
           ]
)