

class DictOvPer:
    __main__dict__ = dict()
    __al__ = "آ".encode('utf-8')
    __a__ = "ا".encode('utf-8')
    __be__ = "ب".encode('utf-8')
    __pe__ = "پ".encode('utf-8')
    __te__ = "ت".encode('utf-8')
    __se__ = "ث".encode('utf-8')
    __jim__ = "ج".encode('utf-8')
    __che__ = "چ".encode('utf-8')
    __heh__ = "ح".encode('utf-8')
    __khe__ = "خ".encode('utf-8')
    __dal__ = "د".encode('utf-8')
    __zal__ = "ذ".encode('utf-8')
    __re__ = "ر".encode('utf-8')
    __ze__ = "ز".encode('utf-8')
    __zhe__ = "ژ".encode('utf-8')
    __sin__ = "س".encode('utf-8')
    __shin__ = "ش".encode('utf-8')
    __sad__ = "ص".encode('utf-8')
    __zad__ = "ض".encode('utf-8')
    __ta__ = "ط".encode('utf-8')
    __za__ = "ظ".encode('utf-8')
    __ain__ = "ع".encode('utf-8')
    __ghain__ = "غ".encode('utf-8')
    __kaf__ = "ک".encode('utf-8')
    __gaf__ = "گ".encode('utf-8')
    __qaf__ = "ق".encode('utf-8')
    __faf__ = "ف".encode('utf-8')
    __he__ = "ه".encode('utf-8')
    __ye__ = "ی".encode('utf-8')
    __non__ = "ن".encode('utf-8')
    __lam__ = "ل".encode('utf-8')
    __mim__ = "م".encode('utf-8')
    __vav__ = "و".encode('utf-8')
    __hmz__ = "ء".encode('utf-8')
    __ymz__ = "ئ".encode('utf-8')
    __spc__ = " ".encode('utf-8')



    __main__dict__[__al__] = '{Jd21}'
    __main__dict__[__be__] = '{Cd01}'
    __main__dict__[__pe__] = '{Fd10}'
    __main__dict__[__te__] = '{Fg89}'
    __main__dict__[__se__] = '{Kd00}'
    __main__dict__[__jim__] = '{Sd20}'
    __main__dict__[__che__] = '{Ss09}'
    __main__dict__[__heh__] = '{Sh90}'
    __main__dict__[__khe__] = '{Sg10}'
    __main__dict__[__dal__] = '{Sw23}'
    __main__dict__[__zal__] = '{Sx90}'
    __main__dict__[__re__] = '{Sx91}'
    __main__dict__[__ze__] = '{Sx92}'
    __main__dict__[__zhe__] = '{Sx93}'
    __main__dict__[__sad__] = '{Xd23}'
    __main__dict__[__zad__] = '{Xd43}'
    __main__dict__[__ta__] = '{Xd44}'
    __main__dict__[__za__] = '{Xd45}'
    __main__dict__[__sin__] = '{Xd11}'
    __main__dict__[__shin__] = '{Xd90}'
    __main__dict__[__ain__] = '{Xa70}'
    __main__dict__[__ghain__] = '{Xi32}'
    __main__dict__[__qaf__] = '{Xi90}'
    __main__dict__[__kaf__] = '{Xi78}'
    __main__dict__[__gaf__] = '{Xi23}'
    __main__dict__[__faf__] = '{Xi50}'
    __main__dict__[__he__] = '{Xo32}'
    __main__dict__[__ye__] = '{Cx32}'
    __main__dict__[__non__] = '{Xf32}'
    __main__dict__[__mim__] = '{Fx32}'
    __main__dict__[__vav__] = '{Fd54}'
    __main__dict__[__hmz__] = '{Fp76}'
    __main__dict__[__ymz__] = '{VvVv}'
    __main__dict__[__spc__] = '{Sp01}'
    __main__dict__[__lam__] = '{So01}'
    __main__dict__[__a__] = '{Sl01}'


    def Encode(self, solo: str):
        list_solo = list(solo)
        mean_code = []
        print(self.__main__dict__)
        for plet in list_solo:
            mean_code.append(self.__main__dict__[plet.encode('utf-8')])
        return '%'.join(mean_code)

